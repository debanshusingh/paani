#paani

CIS 660 Authoring Tool Project
debanshu singh & sanchit garg

Based on - Miles Macklin, Matthias Müller: Position Based Fluids, ACM Transactions on Graphics (SIGGRAPH 2013)

============
Requirements
============
Works on Mac OS X 10.9+ only

=====
Usage
=====
Build paani.xcodeproj & Run
Press q to quit

